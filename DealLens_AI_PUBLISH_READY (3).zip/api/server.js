import express from 'express';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(cors());
app.use(express.json({limit:'5mb'}));

const products = [
 {id:'dl-001',name:'Wireless Headphones',category:'electronics',offers:[{merchant:'Demo Store A',price:49},{merchant:'Demo Store B',price:55},{merchant:'Demo Store C',price:61}]},
 {id:'dl-002',name:'Smart Watch',category:'electronics',offers:[{merchant:'Demo Store A',price:79},{merchant:'Demo Store B',price:89},{merchant:'Demo Store C',price:99}]},
 {id:'dl-003',name:'Running Shoes',category:'fashion',offers:[{merchant:'Demo Store A',price:65},{merchant:'Demo Store B',price:72},{merchant:'Demo Store C',price:80}]}
];

function score(offers){
 if(!offers?.length) return 0;
 const prices=offers.map(o=>Number(o.price)).filter(Number.isFinite);
 const min=Math.min(...prices), max=Math.max(...prices);
 if(min===max) return 70;
 return Math.max(1,Math.min(99,Math.round(60+((max-min)/max)*40)));
}
app.get('/api/health',(req,res)=>res.json({ok:true,service:'DealLens AI API',version:'0.6.0'}));
app.get('/api/search',(req,res)=>{
 const q=String(req.query.q||'').trim().toLowerCase();
 const items=q?products.filter(p=>p.name.toLowerCase().includes(q)||p.category.includes(q)):products;
 res.json({demo:true,items:items.map(p=>({...p,dealScore:score(p.offers)}))});
});
app.post('/api/score',(req,res)=>res.json({demo:true,dealScore:score(req.body.offers||[]),note:'Replace with production scoring model.'}));
app.post('/api/listing',(req,res)=>{
 const name=String(req.body.name||'Product').trim();
 const condition=String(req.body.condition||'Good').trim();
 res.json({demo:true,title:`${name} — ${condition}`,description:`${name} in ${condition} condition. Add verified specifications, delivery details and final price before publishing.`,hashtags:['#DealLensAI','#ForSale','#Deal']});
});

app.use(express.static(path.join(__dirname,'..')));
const PORT=process.env.PORT||3000;
app.listen(PORT,()=>console.log(`DealLens AI running on http://localhost:${PORT}`));
